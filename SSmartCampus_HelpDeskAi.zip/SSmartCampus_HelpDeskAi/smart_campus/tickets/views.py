from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from .models import Ticket
from .serializers import TicketSerializer
from django.db.models import Q




@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def ticket_list(request):

    if request.method == 'GET':
        tickets = Ticket.objects.all()

        category = request.query_params.get('category')
        status = request.query_params.get('status')
        search = request.query_params.get('search')
        ordering = request.query_params.get('ordering')

        if category:
            tickets = tickets.filter(category=category)

        if status:
            tickets = tickets.filter(status=status)

        if search:
             tickets = tickets.filter(
             Q(title__icontains=search) |
            Q(description__icontains=search)
    )

        if ordering:
            tickets = tickets.order_by(ordering)

        paginator = PageNumberPagination()
        paginator.page_size = 5
        paginated_data = paginator.paginate_queryset(tickets, request)

        serializer = TicketSerializer(paginated_data, many=True)
        return paginator.get_paginated_response(serializer.data)

    if request.method == 'POST':
        serializer = TicketSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)



@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@permission_classes([IsAuthenticated])
def ticket_detail(request, id):

    try:
        ticket = Ticket.objects.get(id=id)
    except Ticket.DoesNotExist:
        return Response({"error": "Ticket not found"}, status=404)

    if request.method == 'GET':
        serializer = TicketSerializer(ticket)
        return Response(serializer.data)
    ordering = request.query_params.get('ordering')

    if ordering:
        tickets = tickets.order_by(ordering)
    

    if request.method == 'PUT':
        serializer = TicketSerializer(ticket, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)

    if request.method == 'PATCH':
        serializer = TicketSerializer(ticket, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=400)

    if request.method == 'DELETE':
        ticket.delete()
        return Response({"message": "Ticket deleted successfully"})